// Predicted outcomes 

//Problem 1 
// console.log(randomCar) = Tesla
// consolege.log(otherRandomCar) = Mercedes 

//Problem 2 
//console.log(name); outcome == error name is outside of the scope 
//console.log(otherName); outcome ==  Elon


//Problem 3 
//console.log(password) //outcome == will give error [ FALSE Gave 12345]
//console.log(hashedPassword) outcome ==  undefined 

//Problem 4
//console.log(first == second); outcome == false first equals 2 second - 5
//console.log(first == third); outcome == true first = 2 and so does the 9th element 

//Problem 5 

//Predict the output
//console.log(key); outcome == value 
//console.log(secondKey); will return the array at the secondkey
//console.log(secondKey[0]); returns 1 
//console.log(willThisWork); will be 5 

